"use client"

import { useState } from "react"
import { 
  BarChart3, 
  TrendingUp, 
  Clock, 
  Target,
  Zap,
  Flame,
  Calendar,
  BookOpen
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { AppLayout } from "@/components/navigation"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Area,
  AreaChart
} from "recharts"

type TimeRange = "week" | "month" | "year"

const weeklyStudyData = [
  { day: "Mon", hours: 2.5, xp: 150 },
  { day: "Tue", hours: 3.2, xp: 192 },
  { day: "Wed", hours: 1.8, xp: 108 },
  { day: "Thu", hours: 4.0, xp: 240 },
  { day: "Fri", hours: 2.8, xp: 168 },
  { day: "Sat", hours: 3.5, xp: 210 },
  { day: "Sun", hours: 2.0, xp: 120 },
]

const monthlyXpData = [
  { week: "Week 1", xp: 850 },
  { week: "Week 2", xp: 1200 },
  { week: "Week 3", xp: 980 },
  { week: "Week 4", xp: 1450 },
]

const subjectData = [
  { name: "Mathematics", hours: 12, color: "oklch(0.65 0.2 145)" },
  { name: "Science", hours: 8, color: "oklch(0.7 0.18 55)" },
  { name: "History", hours: 6, color: "oklch(0.6 0.15 280)" },
  { name: "Languages", hours: 5, color: "oklch(0.7 0.15 200)" },
  { name: "Others", hours: 4, color: "oklch(0.65 0.2 340)" },
]

const streakHistory = [
  { month: "Sep", streak: 12 },
  { month: "Oct", streak: 18 },
  { month: "Nov", streak: 7 },
  { month: "Dec", streak: 25 },
  { month: "Jan", streak: 30 },
  { month: "Feb", streak: 15 },
]

const stats = [
  { label: "Total Study Hours", value: "127", change: "+12%", icon: Clock, color: "text-primary" },
  { label: "Total XP Earned", value: "10,450", change: "+8%", icon: Zap, color: "text-accent" },
  { label: "Longest Streak", value: "30 days", change: "+5", icon: Flame, color: "text-[oklch(0.65_0.22_30)]" },
  { label: "Sessions Completed", value: "89", change: "+15%", icon: Target, color: "text-primary" },
]

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState<TimeRange>("week")

  return (
    <AppLayout>
      <div className="p-4 md:p-8">
        <div className="mx-auto max-w-6xl">
          {/* Header */}
          <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground md:text-3xl">
                Analytics
              </h1>
              <p className="text-muted-foreground">
                Track your study progress and patterns
              </p>
            </div>
            <div className="flex gap-2">
              {(["week", "month", "year"] as TimeRange[]).map((range) => (
                <Button
                  key={range}
                  variant={timeRange === range ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTimeRange(range)}
                  className="rounded-full capitalize"
                >
                  {range}
                </Button>
              ))}
            </div>
          </div>

          {/* Stats Grid */}
          <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {stats.map((stat) => {
              const Icon = stat.icon
              return (
                <Card key={stat.label} className="border-border bg-card">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className={`rounded-xl bg-secondary p-2.5 ${stat.color}`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <span className="text-sm font-medium text-primary">{stat.change}</span>
                    </div>
                    <p className="mt-3 text-2xl font-bold text-foreground">{stat.value}</p>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Study Hours Chart */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Clock className="h-5 w-5 text-primary" />
                  Study Hours This Week
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={weeklyStudyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis 
                        dataKey="day" 
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                      />
                      <YAxis 
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                        tickFormatter={(value) => `${value}h`}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: "var(--card)", 
                          border: "1px solid var(--border)",
                          borderRadius: "8px"
                        }}
                        labelStyle={{ color: "var(--foreground)" }}
                      />
                      <Bar 
                        dataKey="hours" 
                        fill="var(--primary)" 
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* XP Progress Chart */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <TrendingUp className="h-5 w-5 text-accent" />
                  XP Progress This Month
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={monthlyXpData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis 
                        dataKey="week" 
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                      />
                      <YAxis 
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: "var(--card)", 
                          border: "1px solid var(--border)",
                          borderRadius: "8px"
                        }}
                        labelStyle={{ color: "var(--foreground)" }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="xp" 
                        stroke="var(--accent)" 
                        fill="var(--accent)"
                        fillOpacity={0.2}
                        strokeWidth={2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Subject Distribution */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <BookOpen className="h-5 w-5 text-primary" />
                  Study Time by Subject
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-6 md:flex-row md:items-center">
                  <div className="h-48 w-48 mx-auto md:mx-0">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={subjectData}
                          cx="50%"
                          cy="50%"
                          innerRadius={50}
                          outerRadius={70}
                          paddingAngle={3}
                          dataKey="hours"
                        >
                          {subjectData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: "var(--card)", 
                            border: "1px solid var(--border)",
                            borderRadius: "8px"
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex-1 space-y-3">
                    {subjectData.map((subject) => (
                      <div key={subject.name} className="flex items-center gap-3">
                        <div 
                          className="h-3 w-3 rounded-full" 
                          style={{ backgroundColor: subject.color }}
                        />
                        <span className="flex-1 text-sm text-foreground">{subject.name}</span>
                        <span className="text-sm font-medium text-muted-foreground">{subject.hours}h</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Streak History */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Flame className="h-5 w-5 text-[oklch(0.65_0.22_30)]" />
                  Streak History
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={streakHistory}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis 
                        dataKey="month" 
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                      />
                      <YAxis 
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: "var(--card)", 
                          border: "1px solid var(--border)",
                          borderRadius: "8px"
                        }}
                        labelStyle={{ color: "var(--foreground)" }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="streak" 
                        stroke="oklch(0.65 0.22 30)" 
                        strokeWidth={2}
                        dot={{ fill: "oklch(0.65 0.22 30)", strokeWidth: 2 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Weekly Goals */}
          <Card className="mt-6 border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Target className="h-5 w-5 text-primary" />
                Weekly Goals Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {[
                  { label: "Study 20 hours", current: 15.8, target: 20, unit: "hours" },
                  { label: "Complete 10 sessions", current: 8, target: 10, unit: "sessions" },
                  { label: "Earn 1000 XP", current: 850, target: 1000, unit: "XP" },
                  { label: "Maintain 7-day streak", current: 7, target: 7, unit: "days" },
                ].map((goal) => {
                  const progress = (goal.current / goal.target) * 100
                  const isComplete = progress >= 100
                  return (
                    <div key={goal.label}>
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-sm font-medium text-foreground">{goal.label}</span>
                        <span className={`text-sm ${isComplete ? "text-primary font-medium" : "text-muted-foreground"}`}>
                          {goal.current} / {goal.target} {goal.unit}
                        </span>
                      </div>
                      <Progress value={Math.min(progress, 100)} className="h-2" />
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  )
}
