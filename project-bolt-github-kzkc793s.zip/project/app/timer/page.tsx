"use client"

import { useState, useEffect, useCallback } from "react"
import {
  Play,
  Pause,
  RotateCcw,
  Coffee,
  BookOpen,
  Zap,
  Trophy,
  Settings,
  Volume2,
  VolumeX
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { AppLayout } from "@/components/navigation"
import { cn } from "@/lib/utils"
import { getCurrentUser } from "@/lib/auth"
import { saveStudySession } from "@/lib/sessions"
import { useToast } from "@/hooks/use-toast"

type TimerMode = "focus" | "shortBreak" | "longBreak"

const timerModes = {
  focus: { duration: 25 * 60, label: "Focus Time", icon: BookOpen, xp: 25 },
  shortBreak: { duration: 5 * 60, label: "Short Break", icon: Coffee, xp: 5 },
  longBreak: { duration: 15 * 60, label: "Long Break", icon: Coffee, xp: 10 },
}

export default function TimerPage() {
  const [mode, setMode] = useState<TimerMode>("focus")
  const [timeLeft, setTimeLeft] = useState(timerModes.focus.duration)
  const [isRunning, setIsRunning] = useState(false)
  const [sessionsCompleted, setSessionsCompleted] = useState(0)
  const [totalXpEarned, setTotalXpEarned] = useState(0)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [userId, setUserId] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    const loadUser = async () => {
      const user = await getCurrentUser()
      if (user) {
        setUserId(user.id)
      }
    }
    loadUser()
  }, [])

  const currentMode = timerModes[mode]
  const progress = ((currentMode.duration - timeLeft) / currentMode.duration) * 100

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleModeChange = (newMode: TimerMode) => {
    setMode(newMode)
    setTimeLeft(timerModes[newMode].duration)
    setIsRunning(false)
  }

  const handleReset = () => {
    setTimeLeft(currentMode.duration)
    setIsRunning(false)
  }

  const handleComplete = useCallback(async () => {
    setIsRunning(false)
    setTotalXpEarned(prev => prev + currentMode.xp)

    if (userId) {
      try {
        await saveStudySession(userId, mode, currentMode.duration / 60)
        toast({
          title: "Session completed!",
          description: `You earned ${currentMode.xp} XP`,
        })
      } catch (error) {
        console.error('Error saving session:', error)
        toast({
          title: "Warning",
          description: "Session not saved. Please check your connection.",
          variant: "destructive"
        })
      }
    }

    if (mode === "focus") {
      setSessionsCompleted(prev => prev + 1)
      if ((sessionsCompleted + 1) % 4 === 0) {
        handleModeChange("longBreak")
      } else {
        handleModeChange("shortBreak")
      }
    } else {
      handleModeChange("focus")
    }
  }, [mode, sessionsCompleted, currentMode.xp, currentMode.duration, userId, toast])

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      handleComplete()
    }

    return () => clearInterval(interval)
  }, [isRunning, timeLeft, handleComplete])

  return (
    <AppLayout>
      <div className="flex min-h-[calc(100vh-7rem)] md:min-h-screen items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-lg">
          {/* Mode Selector */}
          <div className="mb-8 flex items-center justify-center gap-2">
            {(Object.keys(timerModes) as TimerMode[]).map((m) => {
              const Icon = timerModes[m].icon
              return (
                <Button
                  key={m}
                  variant={mode === m ? "default" : "ghost"}
                  size="sm"
                  onClick={() => handleModeChange(m)}
                  className={cn(
                    "rounded-full",
                    mode === m && "shadow-lg"
                  )}
                >
                  <Icon className="mr-2 h-4 w-4" />
                  {timerModes[m].label}
                </Button>
              )
            })}
          </div>

          {/* Timer Card */}
          <Card className="border-border bg-card overflow-hidden">
            <CardContent className="p-8 md:p-12">
              {/* Timer Display */}
              <div className="relative mb-8">
                <div className="mx-auto flex h-64 w-64 items-center justify-center rounded-full border-8 border-secondary bg-background md:h-72 md:w-72">
                  <div className="text-center">
                    <p className="text-6xl font-bold tabular-nums text-foreground md:text-7xl">
                      {formatTime(timeLeft)}
                    </p>
                    <p className="mt-2 text-sm text-muted-foreground">
                      {currentMode.label}
                    </p>
                  </div>
                </div>
                
                {/* Circular Progress */}
                <svg 
                  className="absolute inset-0 -rotate-90 transform" 
                  viewBox="0 0 288 288"
                >
                  <circle
                    cx="144"
                    cy="144"
                    r="124"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="8"
                    className="text-primary/20"
                  />
                  <circle
                    cx="144"
                    cy="144"
                    r="124"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={2 * Math.PI * 124}
                    strokeDashoffset={2 * Math.PI * 124 * (1 - progress / 100)}
                    className="text-primary transition-all duration-1000"
                  />
                </svg>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-4">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-12 w-12 rounded-full"
                  onClick={handleReset}
                >
                  <RotateCcw className="h-5 w-5" />
                </Button>
                
                <Button
                  size="lg"
                  className="h-16 w-16 rounded-full shadow-lg"
                  onClick={() => setIsRunning(!isRunning)}
                >
                  {isRunning ? (
                    <Pause className="h-7 w-7" />
                  ) : (
                    <Play className="h-7 w-7 ml-1" />
                  )}
                </Button>

                <Button
                  variant="outline"
                  size="icon"
                  className="h-12 w-12 rounded-full"
                  onClick={() => setSoundEnabled(!soundEnabled)}
                >
                  {soundEnabled ? (
                    <Volume2 className="h-5 w-5" />
                  ) : (
                    <VolumeX className="h-5 w-5" />
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Stats */}
          <div className="mt-8 grid grid-cols-2 gap-4">
            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-3 p-4">
                <div className="rounded-xl bg-primary/10 p-3">
                  <Trophy className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{sessionsCompleted}</p>
                  <p className="text-xs text-muted-foreground">Sessions</p>
                </div>
              </CardContent>
            </Card>
            
            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-3 p-4">
                <div className="rounded-xl bg-accent/10 p-3">
                  <Zap className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{totalXpEarned}</p>
                  <p className="text-xs text-muted-foreground">XP Earned</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tips */}
          <div className="mt-6 rounded-xl bg-secondary/50 p-4">
            <p className="text-sm text-muted-foreground">
              <span className="font-medium text-foreground">Tip:</span> Complete 4 focus sessions to earn a long break! 
              Each focus session awards {timerModes.focus.xp} XP.
            </p>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
