"use client"

import Link from "next/link"
import { Zap, Trophy, Timer, ChartBar as BarChart3, Flame, Star, ChevronRight, CircleCheck as CheckCircle2, Users, Target } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ThemeToggle } from "@/components/theme-toggle"

const features = [
  {
    icon: Flame,
    title: "Daily Streaks",
    description: "Build consistency with streak tracking that rewards your daily study habits."
  },
  {
    icon: Trophy,
    title: "XP & Levels",
    description: "Earn experience points for every study session and level up your knowledge."
  },
  {
    icon: Timer,
    title: "Pomodoro Timer",
    description: "Stay focused with built-in study timers and break reminders."
  },
  {
    icon: BarChart3,
    title: "Progress Analytics",
    description: "Track your study patterns with detailed charts and insights."
  },
  {
    icon: Users,
    title: "Leaderboards",
    description: "Compete with friends and climb the ranks to become the top student."
  },
  {
    icon: Target,
    title: "Achievements",
    description: "Unlock badges and achievements as you reach new milestones."
  }
]

const stats = [
  { value: "10K+", label: "Active Students" },
  { value: "1M+", label: "Study Hours" },
  { value: "50K+", label: "Achievements Unlocked" },
]

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary">
              <Zap className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">Study Quest</span>
          </Link>
          
          <div className="flex items-center gap-3">
            <ThemeToggle />
            <Link href="/auth">
              <Button variant="outline" size="sm" className="hidden sm:flex">
                Log in
              </Button>
            </Link>
            <Link href="/auth">
              <Button size="sm" className="rounded-full">
                Get Started
                <ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden px-4 py-20 md:py-32">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background" />
        
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
            <Star className="h-4 w-4" />
            Join 10,000+ students leveling up
          </div>
          
          <h1 className="mb-6 text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl lg:text-7xl">
            Turn Studying Into
            <span className="block text-primary">a Game</span>
          </h1>
          
          <p className="mx-auto mb-10 max-w-2xl text-pretty text-lg text-muted-foreground md:text-xl">
            Stay motivated and consistent with gamified study sessions. 
            Earn XP, maintain streaks, unlock achievements, and compete with friends.
          </p>
          
          <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <Link href="/auth">
              <Button size="lg" className="h-12 rounded-full px-8 text-base">
                Start Your Quest
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="#features">
              <Button variant="outline" size="lg" className="h-12 rounded-full px-8 text-base">
                Learn More
              </Button>
            </Link>
          </div>

          {/* Hero Stats */}
          <div className="mt-16 flex flex-wrap items-center justify-center gap-8 md:gap-16">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl font-bold text-foreground md:text-4xl">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Floating Elements */}
        <div className="pointer-events-none absolute left-10 top-32 hidden animate-pulse md:block">
          <div className="rounded-xl bg-accent/80 p-3 shadow-lg">
            <Flame className="h-6 w-6 text-accent-foreground" />
          </div>
        </div>
        <div className="pointer-events-none absolute right-16 top-48 hidden animate-pulse md:block" style={{ animationDelay: "0.5s" }}>
          <div className="rounded-xl bg-primary/80 p-3 shadow-lg">
            <Trophy className="h-6 w-6 text-primary-foreground" />
          </div>
        </div>
        <div className="pointer-events-none absolute bottom-32 right-24 hidden animate-pulse md:block" style={{ animationDelay: "1s" }}>
          <div className="rounded-xl bg-card p-3 shadow-lg border border-border">
            <Star className="h-6 w-6 text-accent" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="px-4 py-20 md:py-28">
        <div className="mx-auto max-w-6xl">
          <div className="mb-16 text-center">
            <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
              Everything You Need to Succeed
            </h2>
            <p className="mx-auto max-w-2xl text-pretty text-muted-foreground">
              Powerful features designed to keep you motivated and help you build 
              lasting study habits.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => {
              const Icon = feature.icon
              return (
                <Card key={feature.title} className="group border-border bg-card transition-all hover:border-primary/50 hover:shadow-lg">
                  <CardContent className="p-6">
                    <div className="mb-4 inline-flex rounded-xl bg-primary/10 p-3 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                      <Icon className="h-6 w-6" />
                    </div>
                    <h3 className="mb-2 text-lg font-semibold text-foreground">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="bg-secondary/50 px-4 py-20 md:py-28">
        <div className="mx-auto max-w-4xl">
          <div className="mb-16 text-center">
            <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
              How Study Quest Works
            </h2>
            <p className="text-pretty text-muted-foreground">
              Get started in minutes and transform your study routine.
            </p>
          </div>

          <div className="space-y-8">
            {[
              { step: "1", title: "Create Your Profile", description: "Sign up and customize your student avatar. Set your study goals and preferences." },
              { step: "2", title: "Start Studying", description: "Use the Pomodoro timer to focus on your tasks. Complete study sessions to earn XP." },
              { step: "3", title: "Track Progress", description: "Watch your level grow, maintain your streak, and climb the leaderboard." },
            ].map((item) => (
              <div key={item.step} className="flex gap-6">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary text-xl font-bold text-primary-foreground">
                  {item.step}
                </div>
                <div>
                  <h3 className="mb-1 text-lg font-semibold text-foreground">{item.title}</h3>
                  <p className="text-muted-foreground">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-4 py-20 md:py-28">
        <div className="mx-auto max-w-4xl text-center">
          <div className="rounded-3xl bg-primary/10 p-8 md:p-16">
            <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
              Ready to Level Up Your Studies?
            </h2>
            <p className="mx-auto mb-8 max-w-xl text-pretty text-muted-foreground">
              Join thousands of students who are making studying fun and building 
              habits that last.
            </p>
            <Link href="/auth">
              <Button size="lg" className="h-12 rounded-full px-8 text-base">
                Start Your Quest Today
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border px-4 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 sm:flex-row">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Zap className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-semibold text-foreground">Study Quest</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Made with love for students everywhere
          </p>
        </div>
      </footer>
    </div>
  )
}
