"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Flame, Zap, Trophy, Timer, CircleCheck as CheckCircle2, Plus, ChevronRight, Target, TrendingUp, Trash2, CreditCard as Edit, Lock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { AppLayout } from "@/components/navigation"
import { getCurrentUser, getProfile } from "@/lib/auth"
import { getTasks, createTask, completeTask, deleteTask } from "@/lib/tasks"
import { getSessionStats } from "@/lib/sessions"
import { Task, Profile } from "@/lib/supabase"
import { useToast } from "@/hooks/use-toast"

export default function DashboardPage() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [profile, setProfile] = useState<Profile | null>(null)
  const [stats, setStats] = useState({ totalXP: 0, totalSessions: 0, totalHours: 0 })
  const [loading, setLoading] = useState(true)
  const [newTaskTitle, setNewTaskTitle] = useState("")
  const [newTaskSubject, setNewTaskSubject] = useState("")
  const [dialogOpen, setDialogOpen] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const user = await getCurrentUser()
      if (!user) {
        toast({
          title: "Not logged in",
          description: "Please sign in to view your dashboard",
          variant: "destructive"
        })
        return
      }

      const [profileData, tasksData, sessionStats] = await Promise.all([
        getProfile(user.id),
        getTasks(user.id),
        getSessionStats(user.id, 1)
      ])

      setProfile(profileData)
      setTasks(tasksData)
      setStats({
        totalXP: sessionStats.totalXP,
        totalSessions: sessionStats.totalSessions,
        totalHours: sessionStats.totalHours
      })
    } catch (error) {
      console.error('Error loading dashboard:', error)
      toast({
        title: "Error",
        description: "Failed to load dashboard data",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const handleAddTask = async () => {
    if (!newTaskTitle.trim() || !profile) return

    try {
      const task = await createTask(
        profile.id,
        newTaskTitle,
        newTaskSubject || "General",
        25
      )
      setTasks([task, ...tasks])
      setNewTaskTitle("")
      setNewTaskSubject("")
      setDialogOpen(false)
      toast({
        title: "Task created",
        description: "New study task added successfully"
      })
    } catch (error) {
      console.error('Error creating task:', error)
      toast({
        title: "Error",
        description: "Failed to create task",
        variant: "destructive"
      })
    }
  }

  const handleToggleTask = async (task: Task) => {
    if (!profile || task.completed) return

    try {
      await completeTask(task.id, profile.id, task.xp_reward)
      setTasks(tasks.map(t =>
        t.id === task.id ? { ...t, completed: true, completed_at: new Date().toISOString() } : t
      ))

      setProfile({
        ...profile,
        total_xp: profile.total_xp + task.xp_reward,
        level: Math.floor((profile.total_xp + task.xp_reward) / 500) + 1
      })

      toast({
        title: "Task completed!",
        description: `You earned ${task.xp_reward} XP`,
      })
    } catch (error) {
      console.error('Error completing task:', error)
      toast({
        title: "Error",
        description: "Failed to complete task",
        variant: "destructive"
      })
    }
  }

  const handleDeleteTask = async (taskId: string) => {
    try {
      await deleteTask(taskId)
      setTasks(tasks.filter(t => t.id !== taskId))
      toast({
        title: "Task deleted",
        description: "Task removed successfully"
      })
    } catch (error) {
      console.error('Error deleting task:', error)
      toast({
        title: "Error",
        description: "Failed to delete task",
        variant: "destructive"
      })
    }
  }

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading dashboard...</p>
          </div>
        </div>
      </AppLayout>
    )
  }

  if (!profile) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center min-h-screen">
          <Card className="w-full max-w-md">
            <CardContent className="p-6 text-center">
              <p className="text-muted-foreground mb-4">Please sign in to view your dashboard</p>
              <Button asChild>
                <Link href="/">Go to Home</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    )
  }

  const completedTasks = tasks.filter(t => t.completed).length
  const totalXpToday = tasks.filter(t => t.completed).reduce((sum, t) => sum + t.xp_reward, 0)
  const xpForNextLevel = (profile.level) * 500
  const xpProgress = (profile.total_xp % 500) / 500 * 100

  return (
    <AppLayout>
      <div className="p-4 md:p-8">
        <div className="mx-auto max-w-6xl">
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-foreground md:text-3xl">
              Welcome back, {profile.username}!
            </h1>
            <p className="text-muted-foreground">
              Ready to continue your learning quest?
            </p>
          </div>

          <div className="mb-8 grid gap-4 sm:grid-cols-3">
            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-4 p-4">
                <div className="rounded-xl bg-secondary p-3 text-accent">
                  <Zap className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stats.totalXP}</p>
                  <p className="text-sm text-muted-foreground">Today's XP</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-4 p-4">
                <div className="rounded-xl bg-secondary p-3 text-[oklch(0.65_0.22_30)]">
                  <Flame className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{profile.current_streak} days</p>
                  <p className="text-sm text-muted-foreground">Current Streak</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-4 p-4">
                <div className="rounded-xl bg-secondary p-3 text-primary">
                  <Target className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stats.totalSessions}</p>
                  <p className="text-sm text-muted-foreground">Sessions Today</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-6">
              <Card className="border-border bg-card overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
                        <Trophy className="h-7 w-7 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Current Level</p>
                        <p className="text-2xl font-bold text-foreground">Level {profile.level}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">XP Progress</p>
                      <p className="text-lg font-semibold text-foreground">
                        {profile.total_xp.toLocaleString()} / {xpForNextLevel.toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <Progress value={xpProgress} className="h-3" />
                  <p className="mt-2 text-sm text-muted-foreground">
                    {xpForNextLevel - (profile.total_xp % 500)} XP until Level {profile.level + 1}
                  </p>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-lg font-semibold">Study Tasks</CardTitle>
                  <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="ghost" size="sm" className="text-primary">
                        <Plus className="mr-1 h-4 w-4" />
                        Add Task
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Create New Task</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div>
                          <label className="text-sm font-medium mb-2 block">Task Title</label>
                          <Input
                            placeholder="e.g., Complete Math homework"
                            value={newTaskTitle}
                            onChange={(e) => setNewTaskTitle(e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium mb-2 block">Subject</label>
                          <Input
                            placeholder="e.g., Mathematics"
                            value={newTaskSubject}
                            onChange={(e) => setNewTaskSubject(e.target.value)}
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setDialogOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleAddTask} disabled={!newTaskTitle.trim()}>
                          Create Task
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </CardHeader>
                <CardContent className="space-y-3">
                  {tasks.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Target className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>No tasks yet. Create your first study task!</p>
                    </div>
                  ) : (
                    tasks.map((task) => (
                      <div
                        key={task.id}
                        className={`flex items-center gap-4 rounded-xl border p-4 transition-all ${
                          task.completed
                            ? "border-primary/30 bg-primary/5"
                            : "border-border bg-secondary/30 hover:border-primary/50"
                        }`}
                      >
                        <button
                          onClick={() => handleToggleTask(task)}
                          disabled={task.completed}
                          className={`flex h-6 w-6 items-center justify-center rounded-full ${
                            task.completed ? "bg-primary text-primary-foreground" : "border-2 border-muted-foreground hover:border-primary"
                          }`}
                        >
                          {task.completed && <CheckCircle2 className="h-4 w-4" />}
                        </button>
                        <div className="flex-1">
                          <p className={`font-medium ${task.completed ? "text-muted-foreground line-through" : "text-foreground"}`}>
                            {task.title}
                          </p>
                          <p className="text-sm text-muted-foreground">{task.subject}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1 text-accent">
                            <Zap className="h-4 w-4" />
                            <span className="text-sm font-medium">+{task.xp_reward} XP</span>
                          </div>
                          {!task.completed && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => handleDeleteTask(task.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card className="border-border bg-card overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[oklch(0.65_0.22_30)]/10">
                      <Flame className="h-9 w-9 text-[oklch(0.65_0.22_30)]" />
                    </div>
                    <div>
                      <p className="text-3xl font-bold text-foreground">{profile.current_streak}</p>
                      <p className="text-sm text-muted-foreground">Day Streak</p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Complete a study session each day to maintain your streak!
                  </p>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-semibold">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Link href="/timer">
                    <Button variant="outline" className="w-full justify-between">
                      <span className="flex items-center gap-2">
                        <Timer className="h-4 w-4 text-primary" />
                        Start Study Session
                      </span>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/leaderboard">
                    <Button variant="outline" className="w-full justify-between">
                      <span className="flex items-center gap-2">
                        <Trophy className="h-4 w-4 text-accent" />
                        View Leaderboard
                      </span>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/analytics">
                    <Button variant="outline" className="w-full justify-between">
                      <span className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-primary" />
                        View Analytics
                      </span>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3 mb-3">
                    <Lock className="h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-semibold text-foreground mb-1">Premium Features</h3>
                      <p className="text-sm text-muted-foreground">
                        Unlock advanced analytics, custom themes, and more
                      </p>
                    </div>
                  </div>
                  <Button className="w-full" disabled>
                    Coming Soon
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-semibold">Daily Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Tasks Completed</span>
                    <span className="text-sm font-medium text-foreground">{completedTasks}/{tasks.length}</span>
                  </div>
                  <Progress value={tasks.length > 0 ? (completedTasks / tasks.length) * 100 : 0} className="h-2 mb-4" />

                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">XP Earned Today</span>
                    <span className="text-sm font-medium text-accent">{stats.totalXP} XP</span>
                  </div>
                  <Progress value={(stats.totalXP / 200) * 100} className="h-2" />
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
