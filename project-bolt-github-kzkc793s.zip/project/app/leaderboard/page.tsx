"use client"

import { useState, useEffect } from "react"
import { Trophy, Medal, Crown, Zap, Flame, TrendingUp, Lock } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { AppLayout } from "@/components/navigation"
import { getLeaderboard, getUserRank } from "@/lib/leaderboard"
import { getCurrentUser } from "@/lib/auth"
import { Profile } from "@/lib/supabase"
import { cn } from "@/lib/utils"

export default function LeaderboardPage() {
  const [leaderboard, setLeaderboard] = useState<Profile[]>([])
  const [userRank, setUserRank] = useState<number | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadLeaderboard()
  }, [])

  const loadLeaderboard = async () => {
    try {
      const [leaders, user] = await Promise.all([
        getLeaderboard(50),
        getCurrentUser()
      ])

      setLeaderboard(leaders)

      if (user) {
        const rank = await getUserRank(user.id)
        setUserRank(rank)
      }
    } catch (error) {
      console.error('Error loading leaderboard:', error)
    } finally {
      setLoading(false)
    }
  }

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="h-5 w-5 text-[oklch(0.75_0.15_85)]" />
    if (rank === 2) return <Medal className="h-5 w-5 text-[oklch(0.7_0.08_220)]" />
    if (rank === 3) return <Medal className="h-5 w-5 text-[oklch(0.65_0.12_30)]" />
    return null
  }

  const getRankBadgeColor = (rank: number) => {
    if (rank === 1) return "bg-[oklch(0.75_0.15_85)]/10 text-[oklch(0.75_0.15_85)] border-[oklch(0.75_0.15_85)]/20"
    if (rank === 2) return "bg-[oklch(0.7_0.08_220)]/10 text-[oklch(0.7_0.08_220)] border-[oklch(0.7_0.08_220)]/20"
    if (rank === 3) return "bg-[oklch(0.65_0.12_30)]/10 text-[oklch(0.65_0.12_30)] border-[oklch(0.65_0.12_30)]/20"
    return "bg-secondary text-foreground"
  }

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading leaderboard...</p>
          </div>
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout>
      <div className="p-4 md:p-8">
        <div className="mx-auto max-w-4xl">
          <div className="mb-8 text-center">
            <div className="mb-4 flex items-center justify-center">
              <div className="rounded-2xl bg-primary/10 p-4">
                <Trophy className="h-10 w-10 text-primary" />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-foreground md:text-3xl">
              Leaderboard
            </h1>
            <p className="text-muted-foreground">
              Top students ranked by XP earned
            </p>
            {userRank && (
              <p className="mt-2 text-sm text-muted-foreground">
                Your rank: <span className="font-semibold text-primary">#{userRank}</span>
              </p>
            )}
          </div>

          <div className="mb-6 grid gap-4 sm:grid-cols-3">
            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-3 p-4">
                <div className="rounded-xl bg-primary/10 p-3">
                  <Trophy className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{leaderboard.length}</p>
                  <p className="text-xs text-muted-foreground">Total Students</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-3 p-4">
                <div className="rounded-xl bg-accent/10 p-3">
                  <Zap className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">
                    {leaderboard.length > 0 ? leaderboard[0].total_xp.toLocaleString() : 0}
                  </p>
                  <p className="text-xs text-muted-foreground">Top XP</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="flex items-center gap-3 p-4">
                <div className="rounded-xl bg-[oklch(0.65_0.22_30)]/10 p-3">
                  <Flame className="h-5 w-5 text-[oklch(0.65_0.22_30)]" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">
                    {leaderboard.length > 0 ? Math.max(...leaderboard.map(p => p.current_streak)) : 0}
                  </p>
                  <p className="text-xs text-muted-foreground">Longest Streak</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Top Students
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {leaderboard.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground">
                  <Trophy className="mx-auto mb-3 h-12 w-12 opacity-50" />
                  <p>No students yet. Be the first!</p>
                </div>
              ) : (
                leaderboard.map((student, index) => {
                  const rank = index + 1
                  const Icon = getRankIcon(rank)

                  return (
                    <div
                      key={student.id}
                      className={cn(
                        "flex items-center gap-4 rounded-xl border p-4 transition-all",
                        rank <= 3
                          ? "border-primary/30 bg-primary/5"
                          : "border-border bg-secondary/30"
                      )}
                    >
                      <div className={cn(
                        "flex h-12 w-12 items-center justify-center rounded-full font-bold",
                        getRankBadgeColor(rank)
                      )}>
                        {Icon || `#${rank}`}
                      </div>

                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          {student.username.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1">
                        <p className="font-semibold text-foreground">{student.username}</p>
                        <p className="text-sm text-muted-foreground">Level {student.level}</p>
                      </div>

                      <div className="flex flex-col items-end gap-1">
                        <div className="flex items-center gap-1 text-accent">
                          <Zap className="h-4 w-4" />
                          <span className="font-semibold">{student.total_xp.toLocaleString()} XP</span>
                        </div>
                        {student.current_streak > 0 && (
                          <div className="flex items-center gap-1 text-[oklch(0.65_0.22_30)]">
                            <Flame className="h-3 w-3" />
                            <span className="text-xs">{student.current_streak} day streak</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })
              )}
            </CardContent>
          </Card>

          <Card className="mt-6 border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5">
            <CardContent className="p-4">
              <div className="flex items-start gap-3 mb-3">
                <Lock className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Premium Leaderboards</h3>
                  <p className="text-sm text-muted-foreground">
                    Unlock subject-specific leaderboards and weekly competitions
                  </p>
                </div>
              </div>
              <Button className="w-full" disabled>
                Coming Soon
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  )
}
