"use client"

import { useState } from "react"
import { 
  User, 
  Trophy,
  Flame,
  Zap,
  Calendar,
  Clock,
  Star,
  Award,
  Target,
  BookOpen,
  Sparkles,
  Lock,
  CheckCircle2,
  Edit3,
  Camera
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { AppLayout } from "@/components/navigation"
import { cn } from "@/lib/utils"

const achievements = [
  { id: 1, title: "First Steps", description: "Complete your first study session", icon: Star, earned: true, xp: 50 },
  { id: 2, title: "Week Warrior", description: "Study for 7 days in a row", icon: Flame, earned: true, xp: 200 },
  { id: 3, title: "XP Hunter", description: "Earn 5,000 XP", icon: Zap, earned: true, xp: 300 },
  { id: 4, title: "Bookworm", description: "Complete 50 study sessions", icon: BookOpen, earned: true, xp: 400 },
  { id: 5, title: "Level 10", description: "Reach Level 10", icon: Trophy, earned: true, xp: 500 },
  { id: 6, title: "Marathon Learner", description: "Study for 100 hours total", icon: Clock, earned: false, xp: 600, progress: 75 },
  { id: 7, title: "Perfect Month", description: "Maintain a 30-day streak", icon: Calendar, earned: false, xp: 750, progress: 50 },
  { id: 8, title: "Top Student", description: "Reach #1 on leaderboard", icon: Award, earned: false, xp: 1000, progress: 0 },
  { id: 9, title: "XP Master", description: "Earn 50,000 XP", icon: Sparkles, earned: false, xp: 1500, progress: 21 },
]

const stats = [
  { label: "Total XP", value: "10,450", icon: Zap },
  { label: "Current Streak", value: "15 days", icon: Flame },
  { label: "Study Hours", value: "127", icon: Clock },
  { label: "Sessions", value: "89", icon: Target },
]

const recentActivity = [
  { action: "Completed Math session", xp: 25, time: "2 hours ago" },
  { action: "Earned 'Bookworm' badge", xp: 400, time: "Yesterday" },
  { action: "Reached Level 18", xp: 0, time: "2 days ago" },
  { action: "Completed Biology quiz", xp: 50, time: "3 days ago" },
]

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState<"achievements" | "activity">("achievements")
  
  const currentLevel = 18
  const currentXp = 10450
  const xpForNextLevel = 12000
  const xpProgress = (currentXp / xpForNextLevel) * 100
  const earnedAchievements = achievements.filter(a => a.earned).length

  return (
    <AppLayout>
      <div className="p-4 md:p-8">
        <div className="mx-auto max-w-4xl">
          {/* Profile Header */}
          <Card className="mb-8 border-border bg-card overflow-hidden">
            <div className="h-24 bg-gradient-to-r from-primary/20 via-accent/20 to-primary/20" />
            <CardContent className="relative px-6 pb-6">
              <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-end sm:gap-6">
                {/* Avatar */}
                <div className="relative -mt-16">
                  <Avatar className="h-28 w-28 border-4 border-card">
                    <AvatarFallback className="bg-primary text-3xl text-primary-foreground">
                      ST
                    </AvatarFallback>
                  </Avatar>
                  <button className="absolute bottom-0 right-0 flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-foreground shadow-lg hover:bg-secondary/80">
                    <Camera className="h-4 w-4" />
                  </button>
                  {/* Level Badge */}
                  <div className="absolute -right-2 -top-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground shadow-lg">
                    {currentLevel}
                  </div>
                </div>

                {/* User Info */}
                <div className="flex-1 text-center sm:text-left">
                  <div className="flex items-center justify-center gap-2 sm:justify-start">
                    <h1 className="text-2xl font-bold text-foreground">Student Name</h1>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Edit3 className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-muted-foreground">Level {currentLevel} Scholar</p>
                  <div className="mt-2 flex items-center justify-center gap-4 sm:justify-start">
                    <span className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      Joined Jan 2024
                    </span>
                    <span className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Trophy className="h-4 w-4" />
                      Rank #6
                    </span>
                  </div>
                </div>

                {/* XP Progress */}
                <div className="w-full sm:w-48">
                  <div className="mb-2 flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Next Level</span>
                    <span className="font-medium text-foreground">{xpForNextLevel - currentXp} XP</span>
                  </div>
                  <Progress value={xpProgress} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Stats Grid */}
          <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {stats.map((stat) => {
              const Icon = stat.icon
              return (
                <Card key={stat.label} className="border-border bg-card">
                  <CardContent className="flex flex-col items-center p-4 text-center">
                    <Icon className="mb-2 h-6 w-6 text-primary" />
                    <p className="text-xl font-bold text-foreground">{stat.value}</p>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Tabs */}
          <div className="mb-6 flex gap-2">
            <Button
              variant={activeTab === "achievements" ? "default" : "outline"}
              onClick={() => setActiveTab("achievements")}
              className="rounded-full"
            >
              <Award className="mr-2 h-4 w-4" />
              Achievements
            </Button>
            <Button
              variant={activeTab === "activity" ? "default" : "outline"}
              onClick={() => setActiveTab("activity")}
              className="rounded-full"
            >
              <Clock className="mr-2 h-4 w-4" />
              Activity
            </Button>
          </div>

          {/* Achievements Tab */}
          {activeTab === "achievements" && (
            <div>
              <div className="mb-6 flex items-center justify-between">
                <p className="text-muted-foreground">
                  <span className="font-semibold text-foreground">{earnedAchievements}</span> of {achievements.length} achievements unlocked
                </p>
                <div className="flex items-center gap-1 text-accent">
                  <Zap className="h-4 w-4" />
                  <span className="font-medium">{achievements.filter(a => a.earned).reduce((sum, a) => sum + a.xp, 0)} XP earned</span>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {achievements.map((achievement) => {
                  const Icon = achievement.icon
                  return (
                    <Card 
                      key={achievement.id} 
                      className={cn(
                        "border-border bg-card transition-all",
                        achievement.earned 
                          ? "border-primary/30" 
                          : "opacity-75"
                      )}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <div className={cn(
                            "flex h-12 w-12 shrink-0 items-center justify-center rounded-xl",
                            achievement.earned 
                              ? "bg-primary/10 text-primary" 
                              : "bg-secondary text-muted-foreground"
                          )}>
                            {achievement.earned ? (
                              <Icon className="h-6 w-6" />
                            ) : (
                              <Lock className="h-5 w-5" />
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-start justify-between">
                              <h3 className={cn(
                                "font-semibold",
                                achievement.earned ? "text-foreground" : "text-muted-foreground"
                              )}>
                                {achievement.title}
                              </h3>
                              {achievement.earned && (
                                <CheckCircle2 className="h-5 w-5 text-primary" />
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {achievement.description}
                            </p>
                            {!achievement.earned && achievement.progress !== undefined && (
                              <div className="mt-2">
                                <Progress value={achievement.progress} className="h-1.5" />
                                <p className="mt-1 text-xs text-muted-foreground">{achievement.progress}% complete</p>
                              </div>
                            )}
                            <p className="mt-2 flex items-center gap-1 text-sm">
                              <Zap className="h-3 w-3 text-accent" />
                              <span className="font-medium text-accent">+{achievement.xp} XP</span>
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>
          )}

          {/* Activity Tab */}
          {activeTab === "activity" && (
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-lg">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <div 
                    key={index}
                    className="flex items-center gap-4 rounded-lg border border-border bg-secondary/30 p-4"
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Zap className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{activity.action}</p>
                      <p className="text-sm text-muted-foreground">{activity.time}</p>
                    </div>
                    {activity.xp > 0 && (
                      <span className="flex items-center gap-1 text-accent">
                        <Zap className="h-4 w-4" />
                        <span className="font-medium">+{activity.xp} XP</span>
                      </span>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Motivational Card */}
          <Card className="mt-8 border-primary/30 bg-primary/5">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/20">
                <Sparkles className="h-7 w-7 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Keep up the great work!</h3>
                <p className="text-sm text-muted-foreground">
                  You're on a 15-day streak. Just 15 more days to unlock the "Perfect Month" achievement!
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  )
}
