import { useState, useCallback } from 'react'
import { supabase } from '@/lib/supabase'

type SessionType = 'focus' | 'shortBreak' | 'longBreak'

const sessionXP = {
  focus: 25,
  shortBreak: 5,
  longBreak: 10,
}

const sessionDurations = {
  focus: 25,
  shortBreak: 5,
  longBreak: 15,
}

export function useStudySession() {
  const [isSaving, setIsSaving] = useState(false)

  const saveSession = useCallback(async (
    userId: string,
    sessionType: SessionType,
    durationMinutes?: number
  ) => {
    setIsSaving(true)
    try {
      const duration = durationMinutes || sessionDurations[sessionType]
      const xp = sessionXP[sessionType]

      const { data, error } = await supabase
        .from('study_sessions')
        .insert({
          user_id: userId,
          session_type: sessionType,
          duration_minutes: duration,
          xp_earned: xp,
        })
        .select()
        .maybeSingle()

      if (error) throw error

      await updateProfileXP(userId, xp)

      return { success: true, data, xp }
    } catch (error) {
      console.error('Error saving session:', error)
      return { success: false, error }
    } finally {
      setIsSaving(false)
    }
  }, [])

  const updateProfileXP = async (userId: string, xpGained: number) => {
    const { data: profile } = await supabase
      .from('profiles')
      .select('total_xp, level')
      .eq('id', userId)
      .maybeSingle()

    if (profile) {
      const newTotalXp = profile.total_xp + xpGained
      const newLevel = Math.floor(newTotalXp / 500) + 1

      await supabase
        .from('profiles')
        .update({
          total_xp: newTotalXp,
          level: newLevel,
          updated_at: new Date().toISOString(),
        })
        .eq('id', userId)
    }
  }

  return { saveSession, isSaving }
}
