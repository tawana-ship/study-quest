import { supabase } from './supabase'
import { Profile } from './supabase'

export async function getLeaderboard(limit: number = 50) {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, username, level, total_xp, current_streak, avatar_url')
    .order('total_xp', { ascending: false })
    .limit(limit)

  if (error) throw error

  return data as Profile[]
}

export async function getUserRank(userId: string) {
  const { data: allUsers, error } = await supabase
    .from('profiles')
    .select('id, total_xp')
    .order('total_xp', { ascending: false })

  if (error) throw error

  const rank = allUsers.findIndex(u => u.id === userId) + 1
  return rank > 0 ? rank : null
}
