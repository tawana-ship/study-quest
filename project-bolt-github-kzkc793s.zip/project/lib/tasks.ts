import { supabase } from './supabase'
import { Task } from './supabase'

export async function getTasks(userId: string) {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })

  if (error) throw error
  return data as Task[]
}

export async function createTask(
  userId: string,
  title: string,
  subject: string,
  xpReward: number = 25
) {
  const { data, error } = await supabase
    .from('tasks')
    .insert({
      user_id: userId,
      title,
      subject,
      xp_reward: xpReward,
      completed: false,
    })
    .select()
    .maybeSingle()

  if (error) throw error
  return data as Task
}

export async function updateTask(
  taskId: string,
  updates: Partial<Omit<Task, 'id' | 'user_id' | 'created_at'>>
) {
  const { data, error } = await supabase
    .from('tasks')
    .update(updates)
    .eq('id', taskId)
    .select()
    .maybeSingle()

  if (error) throw error
  return data as Task
}

export async function completeTask(taskId: string, userId: string, xpReward: number) {
  const { data, error } = await supabase
    .from('tasks')
    .update({
      completed: true,
      completed_at: new Date().toISOString(),
    })
    .eq('id', taskId)
    .select()
    .maybeSingle()

  if (error) throw error

  await addXP(userId, xpReward)

  return data as Task
}

export async function deleteTask(taskId: string) {
  const { error } = await supabase
    .from('tasks')
    .delete()
    .eq('id', taskId)

  if (error) throw error
}

async function addXP(userId: string, xp: number) {
  const { data: profile } = await supabase
    .from('profiles')
    .select('total_xp, level')
    .eq('id', userId)
    .maybeSingle()

  if (profile) {
    const newTotalXp = profile.total_xp + xp
    const newLevel = Math.floor(newTotalXp / 500) + 1

    await supabase
      .from('profiles')
      .update({
        total_xp: newTotalXp,
        level: newLevel,
        updated_at: new Date().toISOString(),
      })
      .eq('id', userId)
  }
}
