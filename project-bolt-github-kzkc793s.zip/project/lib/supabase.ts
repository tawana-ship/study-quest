import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Profile = {
  id: string
  username: string
  level: number
  total_xp: number
  current_streak: number
  longest_streak: number
  avatar_url: string | null
  created_at: string
  updated_at: string
}

export type StudySession = {
  id: string
  user_id: string
  session_type: 'focus' | 'shortBreak' | 'longBreak'
  duration_minutes: number
  xp_earned: number
  completed_at: string
  created_at: string
}

export type Task = {
  id: string
  user_id: string
  title: string
  subject: string
  xp_reward: number
  completed: boolean
  completed_at: string | null
  created_at: string
}

export type Achievement = {
  id: string
  name: string
  description: string
  icon: string
  xp_reward: number
  requirement: Record<string, any>
}

export type UserAchievement = {
  id: string
  user_id: string
  achievement_id: string
  unlocked_at: string
}
