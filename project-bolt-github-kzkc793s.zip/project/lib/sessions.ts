import { supabase } from './supabase'
import { StudySession } from './supabase'

const SESSION_XP = {
  focus: 25,
  shortBreak: 5,
  longBreak: 10,
}

export async function saveStudySession(
  userId: string,
  sessionType: 'focus' | 'shortBreak' | 'longBreak',
  durationMinutes: number
) {
  const xpEarned = SESSION_XP[sessionType]

  const { data, error } = await supabase
    .from('study_sessions')
    .insert({
      user_id: userId,
      session_type: sessionType,
      duration_minutes: durationMinutes,
      xp_earned: xpEarned,
    })
    .select()
    .maybeSingle()

  if (error) throw error

  await updateProfileXP(userId, xpEarned)
  await updateStreak(userId)

  return data as StudySession
}

export async function getStudySessions(userId: string, limit?: number) {
  let query = supabase
    .from('study_sessions')
    .select('*')
    .eq('user_id', userId)
    .order('completed_at', { ascending: false })

  if (limit) {
    query = query.limit(limit)
  }

  const { data, error } = await query

  if (error) throw error
  return data as StudySession[]
}

export async function getSessionStats(userId: string, days: number = 7) {
  const startDate = new Date()
  startDate.setDate(startDate.getDate() - days)

  const { data, error } = await supabase
    .from('study_sessions')
    .select('*')
    .eq('user_id', userId)
    .gte('completed_at', startDate.toISOString())

  if (error) throw error

  const sessions = data as StudySession[]

  const totalSessions = sessions.length
  const totalMinutes = sessions.reduce((sum, s) => sum + s.duration_minutes, 0)
  const totalXP = sessions.reduce((sum, s) => sum + s.xp_earned, 0)
  const focusSessions = sessions.filter(s => s.session_type === 'focus').length

  return {
    totalSessions,
    totalMinutes,
    totalHours: Math.round(totalMinutes / 60),
    totalXP,
    focusSessions,
  }
}

async function updateProfileXP(userId: string, xpGained: number) {
  const { data: profile } = await supabase
    .from('profiles')
    .select('total_xp, level')
    .eq('id', userId)
    .maybeSingle()

  if (profile) {
    const newTotalXp = profile.total_xp + xpGained
    const newLevel = Math.floor(newTotalXp / 500) + 1

    await supabase
      .from('profiles')
      .update({
        total_xp: newTotalXp,
        level: newLevel,
        updated_at: new Date().toISOString(),
      })
      .eq('id', userId)
  }
}

async function updateStreak(userId: string) {
  const { data: profile } = await supabase
    .from('profiles')
    .select('current_streak, longest_streak')
    .eq('id', userId)
    .maybeSingle()

  if (!profile) return

  const { data: recentSessions } = await supabase
    .from('study_sessions')
    .select('completed_at')
    .eq('user_id', userId)
    .eq('session_type', 'focus')
    .order('completed_at', { ascending: false })
    .limit(50)

  if (!recentSessions || recentSessions.length === 0) return

  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const yesterday = new Date(today)
  yesterday.setDate(yesterday.getDate() - 1)

  const sessionDates = recentSessions.map(s => {
    const date = new Date(s.completed_at)
    date.setHours(0, 0, 0, 0)
    return date.getTime()
  })

  const uniqueDates = [...new Set(sessionDates)].sort((a, b) => b - a)

  let streak = 0
  let expectedDate = today.getTime()

  for (const date of uniqueDates) {
    if (date === expectedDate || date === expectedDate - 86400000) {
      streak++
      expectedDate = date - 86400000
    } else {
      break
    }
  }

  const newLongestStreak = Math.max(streak, profile.longest_streak)

  await supabase
    .from('profiles')
    .update({
      current_streak: streak,
      longest_streak: newLongestStreak,
      updated_at: new Date().toISOString(),
    })
    .eq('id', userId)
}
