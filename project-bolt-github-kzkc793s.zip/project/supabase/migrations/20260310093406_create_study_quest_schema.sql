/*
  # Study Quest Database Schema

  ## Overview
  Creates the core database structure for the Study Quest gamified learning app.

  ## New Tables

  ### 1. profiles
  - Stores user profile information and statistics
  - Fields:
    - `id` (uuid, primary key) - Links to auth.users
    - `username` (text) - Display name
    - `level` (int) - Current user level
    - `total_xp` (int) - Total XP earned
    - `current_streak` (int) - Current study streak in days
    - `longest_streak` (int) - Longest streak achieved
    - `avatar_url` (text) - Profile picture URL
    - `created_at` (timestamptz) - Account creation date
    - `updated_at` (timestamptz) - Last profile update

  ### 2. study_sessions
  - Tracks completed study sessions
  - Fields:
    - `id` (uuid, primary key) - Unique session ID
    - `user_id` (uuid) - References profiles.id
    - `session_type` (text) - Type: focus, shortBreak, or longBreak
    - `duration_minutes` (int) - Session duration
    - `xp_earned` (int) - XP awarded for session
    - `completed_at` (timestamptz) - When session finished
    - `created_at` (timestamptz) - When session started

  ### 3. tasks
  - User's study tasks/todos
  - Fields:
    - `id` (uuid, primary key) - Unique task ID
    - `user_id` (uuid) - References profiles.id
    - `title` (text) - Task description
    - `subject` (text) - Subject area
    - `xp_reward` (int) - XP for completing task
    - `completed` (bool) - Completion status
    - `completed_at` (timestamptz) - Completion timestamp
    - `created_at` (timestamptz) - Creation timestamp

  ### 4. achievements
  - Available achievements in the system
  - Fields:
    - `id` (uuid, primary key) - Unique achievement ID
    - `name` (text) - Achievement name
    - `description` (text) - What it's for
    - `icon` (text) - Icon identifier
    - `xp_reward` (int) - XP bonus
    - `requirement` (jsonb) - Unlock conditions

  ### 5. user_achievements
  - Tracks which achievements users have unlocked
  - Fields:
    - `id` (uuid, primary key) - Unique record ID
    - `user_id` (uuid) - References profiles.id
    - `achievement_id` (uuid) - References achievements.id
    - `unlocked_at` (timestamptz) - When unlocked

  ## Security
  - Row Level Security (RLS) enabled on all tables
  - Users can only access their own data
  - Achievements table is read-only for all users
  - Leaderboard data is publicly readable

  ## Important Notes
  - All timestamps use timestamptz for timezone support
  - XP and streak calculations can be derived from study_sessions
  - Profile stats should be updated via triggers or application logic
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text NOT NULL DEFAULT 'Student',
  level int NOT NULL DEFAULT 1,
  total_xp int NOT NULL DEFAULT 0,
  current_streak int NOT NULL DEFAULT 0,
  longest_streak int NOT NULL DEFAULT 0,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create study_sessions table
CREATE TABLE IF NOT EXISTS study_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  session_type text NOT NULL CHECK (session_type IN ('focus', 'shortBreak', 'longBreak')),
  duration_minutes int NOT NULL,
  xp_earned int NOT NULL DEFAULT 0,
  completed_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Create tasks table
CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  subject text NOT NULL DEFAULT 'General',
  xp_reward int NOT NULL DEFAULT 25,
  completed bool NOT NULL DEFAULT false,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create achievements table
CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  icon text NOT NULL,
  xp_reward int NOT NULL DEFAULT 0,
  requirement jsonb NOT NULL
);

-- Create user_achievements table
CREATE TABLE IF NOT EXISTS user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  achievement_id uuid NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
  unlocked_at timestamptz DEFAULT now(),
  UNIQUE(user_id, achievement_id)
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can view all profiles for leaderboard"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Study sessions policies
CREATE POLICY "Users can view own sessions"
  ON study_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own sessions"
  ON study_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Tasks policies
CREATE POLICY "Users can view own tasks"
  ON tasks FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own tasks"
  ON tasks FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tasks"
  ON tasks FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own tasks"
  ON tasks FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Achievements policies (read-only for all)
CREATE POLICY "Anyone can view achievements"
  ON achievements FOR SELECT
  TO authenticated
  USING (true);

-- User achievements policies
CREATE POLICY "Users can view own achievements"
  ON user_achievements FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own achievements"
  ON user_achievements FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_study_sessions_user_id ON study_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_study_sessions_completed_at ON study_sessions(completed_at);
CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_completed ON tasks(completed);
CREATE INDEX IF NOT EXISTS idx_user_achievements_user_id ON user_achievements(user_id);

-- Insert sample achievements
INSERT INTO achievements (name, description, icon, xp_reward, requirement) VALUES
  ('First Steps', 'Complete your first study session', 'Star', 50, '{"sessions": 1}'),
  ('Dedicated', 'Maintain a 7-day streak', 'Flame', 100, '{"streak": 7}'),
  ('Marathon Runner', 'Complete 100 study sessions', 'Trophy', 500, '{"sessions": 100}'),
  ('Level 10', 'Reach level 10', 'Zap', 200, '{"level": 10}'),
  ('Early Bird', 'Complete a session before 8 AM', 'Sun', 75, '{"early_session": true}'),
  ('Night Owl', 'Complete a session after 10 PM', 'Moon', 75, '{"late_session": true}')
ON CONFLICT DO NOTHING;